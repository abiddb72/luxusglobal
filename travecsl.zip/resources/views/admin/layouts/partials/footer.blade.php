<footer class="main-footer">
  <strong>&copy; {{ date('Y') }} My Admin Panel.</strong> All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 3.2.0
  </div>
</footer>
